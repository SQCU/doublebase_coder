visual-semantic-compression of human-meaningless numerals into compressed typable representations

see example_usage.py for implementation details; copy-pasteable into your favorite LLM